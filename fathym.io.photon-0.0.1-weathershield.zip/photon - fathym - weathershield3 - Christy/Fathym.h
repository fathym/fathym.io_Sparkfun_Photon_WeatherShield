/*
Fathym library for Particle Core & Photon
This software is released under the MIT License.

Copyright (c) 2016 Michael Everett
Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS sIS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

#ifndef _FATHYM
#define _FATHYM

// Load build configuration settings
#include "FathymBuild.h" // uncomment for local Particle Dev build
//#include "../FathymBuild.h"

// Standard Photon library
#include "application.h"

// Include Math library
#include "math.h"

// MQTT library used for underlying message broker communication
#include "MQTT.h"

// If this is a local Particle Dev build, reference dependencies/libraries differently
#ifdef LOCAL_BUILD
// Used for JSON data communications
#include "SparkJson.h"
#else
#include "SparkJson/SparkJson.h"
#endif

// Used for access to device flash storage
#ifdef LOCAL_BUILD
#include "flashee-eeprom.h"
#else
#include "flashee-eeprom/flashee-eeprom.h"
#endif
using namespace Flashee;

// Globals
#define FATHYM_ANALOG   0
#define FATHYM_DIGITAL  1

//==== Device Configuration =====================================================================

  // The flash memory offset where Fathym device configuration settings are written to/read from
  #ifndef FATHYM_CONFIG_ADDRESS
  #define FATHYM_CONFIG_ADDRESS 0
  #endif

  // The character marker to use to indicate that the Fathym EERPOM/Flash configuration storage
  // system has been initialized.
  #define FATHYM_CONFIG_FLAG "Fathym" // not user configurable for now

  // The size of the character buffer used to serialize/deserialize the configuration JSON
  #ifndef FATHYM_CONFIG_BUFFER_SIZE
  #define FATHYM_CONFIG_BUFFER_SIZE 512
  #endif

  // The brightness of connected LEDs (0-255)
  #ifndef FATHYM_LED_BRIGHTNESS
  #define FATHYM_LED_BRIGHTNESS 255
  #endif

//==== End Device Configuration =================================================================

//==== Device Data & Publishing =================================================================

  // The name of the device ID property to use
  #ifndef FATHYM_ID_PROPERTY
  #define FATHYM_ID_PROPERTY "id"
  #endif

  // Whether or not to include the device's name
  #ifndef FATHYM_ADD_DEVICE_NAME
  #define FATHYM_ADD_DEVICE_NAME false
  #endif

  // The name of the device name property to use
  #ifndef FATHYM_DEVICE_NAME_PROPERTY
  #define FATHYM_DEVICE_NAME_PROPERTY "name"
  #endif

  // The default number of decimal places to include from numbers with decimal values
  #ifndef FATHYM_DEFAULT_DECIMAL_PLACES
  #define FATHYM_DEFAULT_DECIMAL_PLACES 3
  #endif

  // The interval in minutes that the device will resynchronize device time to Particle cloud time
  #ifndef FATHYM_RESYNC_TIME_MINS
  #define FATHYM_RESYNC_TIME_MINS 1440 // resync every 24 hours
  #endif

  // Whether or not to include the current uptime of the device
  #ifndef FATHYM_ADD_UPTIME
  #define FATHYM_ADD_UPTIME true
  #endif

  // The name of the device uptime property to use
  #ifndef FATHYM_UPTIME_PROPERTY
  #define FATHYM_UPTIME_PROPERTY "ut"
  #endif

  // Whether or not to include a time stamp on each published message
  #ifndef FATHYM_ADD_TIMESTAMP
  #define FATHYM_ADD_TIMESTAMP true
  #endif

  // The time zone offset to use when adding a time stamp to the published message
  #ifndef FATHYM_TIMEZONE_OFFSET
  #define FATHYM_TIMEZONE_OFFSET -7 // Colorado/Mountain time!
  #endif

  // The name of the time stamp property to use
  #ifndef FATHYM_TIMESTAMP_PROPERTY
  #define FATHYM_TIMESTAMP_PROPERTY "ts"
  #endif

  // Whether or not to include the device's free memory in the message for detecting memory leaks
  #ifndef FATHYM_ADD_FREE_MEMORY
  #define FATHYM_ADD_FREE_MEMORY false
  #endif

  // The name of the free memory property to use
  #ifndef FATHYM_FREE_MEMORY_PROPERTY
  #define FATHYM_FREE_MEMORY_PROPERTY "mem"
  #endif

  // Whether or not the Fathym library will automatically handle publishing data or not
  #ifndef FATHYM_AUTO_PUBLISH
  #define FATHYM_AUTO_PUBLISH true
  #endif

  // The publish rate (in seconds) for message data (applies when FATHYM_AUTO_PUBLISH is set to true)
  #ifndef FATHYM_PUBLISH_RATE
  #define FATHYM_PUBLISH_RATE 10
  #endif

  // The power mode to use for operation and publishing
  // (0 = always on, 1 = WiFi sleep, 2 = Deep Sleep)
  #ifndef FATHYM_POWER_MODE
  #define FATHYM_POWER_MODE 0 // default to always on
  #endif

  // When using a low power/sleep mode, the number of seconds the devicee will start
  // back up ahead of the next publish to be initialized and connected; ready to publish on time.
  #ifndef FATHYM_SLEEP_WAKE_OFFSET
  #define FATHYM_SLEEP_WAKE_OFFSET 5
  #endif

  // Various power modes
  #define FATHYM_POWER_MODE_ALWAYS_ON   0 // device runs continously
  #define FATHYM_POWER_MODE_WIFI_SLEEP  1 // WiFi module is turned on and off on a cycle, but Fathym keeps running
  #define FATHYM_POWER_MODE_DEEP_SLEEP  2 // the whole device goes into deep sleep on a cycle and restarts completely each publish

//==== End Device Data & Publishing =============================================================

//==== Communications & Network =================================================================

  // The protocol to use to publish messages ("MQTT" or "HTTP")
  #ifndef PUBLISH_PROTOCOL
  #define PUBLISH_PROTOCOL "MQTT"
  #endif

  // The server/host/domain name of the HTTP API endpoint to publish to
  #ifndef HTTP_HOST
  #define HTTP_HOST "YourEndpoint.com"
  #endif

  // The relative path api/URL portion of the HTTP API endpoint to publish to
  #ifndef HTTP_URL
  #define HTTP_URL "/api/v1/your/url"
  #endif

  // The port of the HTTP endpoint to publish to
  #ifndef HTTP_PORT
  #define HTTP_PORT 80
  #endif

  // Custom headers separated by new line charater's that are used durring HTTP posts
  //#define HTTP_HEADERS "Header-Values: Separated by new lines\nContent-Type: application/json\n";

  // The buffer size used to read in the response to HTTP POST calls
  #ifndef HTTP_RESPONSE_MAX_SIZE
  #define HTTP_RESPONSE_MAX_SIZE 512
  #endif

  // MQTT message broker to connect to for message queuing and receiving messages
  #ifndef MQTT_SERVER
  #define MQTT_SERVER "your.mqtt.server.com"
  #endif

  // The MQTT credentials username to connect as
  #ifndef MQTT_USERNAME
  #define MQTT_USERNAME "vhost:username"
  #endif

  // The MQTT credentials username to connect as
  #ifndef MQTT_PASSWORD
  #define MQTT_PASSWORD "password"
  #endif

  // The group ID that the device will use for communications with Fathym
  #ifndef MQTT_MESSAGE_GROUP
  #define MQTT_MESSAGE_GROUP "public"
  #endif

  // The port used by the MQTT message broker
  #ifndef MQTT_PORT
  #define MQTT_PORT 1883
  #endif

  // The rate at which the MQTT communication loop updates in milliseconds.
  // This includes ping/keep alive/QoS/receiving messages. It runs on a
  // software timer independent of the main program loop.
  #ifndef MQTT_UPDATE_RATE
  #define MQTT_UPDATE_RATE 1000
  #endif

  // The number of times to run the MQTT communications update loop per
  // iteration as defined by MQTT_UPDATE_RATE. The update loop will consume
  // 1 waiting message per update per update cycle.
  #ifndef MQTT_MESSAGES_PER_UPDATE
  #define MQTT_MESSAGES_PER_UPDATE 10
  #endif

  // The number of seconds to use for the MQTT connection keep alive.
  // The keep alive needs to be longer than your publish rate otherwise
  // the connection will continuously time out/reconnect after one publish.
  #ifndef MQTT_KEEPALIVE
  #define MQTT_KEEPALIVE 40
  #endif

  // The maximum size of the MQTT header in bytes
  #ifndef MQTT_MAX_HEADER_SIZE
  #define MQTT_MAX_HEADER_SIZE 160
  #endif

  // The reserved buffer size in bytes for MQTT data packet buffer.
  // The maximum buffer size available to serialize JSON messages to string
  // is determined by the MQTT_MAX_PACKET_SIZE - MQTT_MAX_HEADER_SIZE.
  #ifndef MQTT_MAX_PACKET_SIZE
  #define MQTT_MAX_PACKET_SIZE 640
  #endif

  // Whether or not to include the current WIFI signal strength
  #ifndef FATHYM_ADD_RSSI
  #define FATHYM_ADD_RSSI false
  #endif

  // The name of the WIFI signal strength/RSSI property to use
  #ifndef FATHYM_RSSI_PROPERTY
  #define FATHYM_RSSI_PROPERTY "rssi"
  #endif

//==== End Communications & Network =============================================================

//==== Debugging ================================================================================

  // Whether or not to use LED(s) to visualize various status indicators around various Fathym events
  #ifndef FATHYM_LED_STATUS
  #define FATHYM_LED_STATUS true
  #endif

  // The LED pin to use when showing status
  #ifndef FATHYM_STATUS_LED_PIN
  #define FATHYM_STATUS_LED_PIN D7
  #endif

  // The LED pin to use when showing successful publish events
  #ifndef FATHYM_PUBLISH_LED_PIN
  #define FATHYM_PUBLISH_LED_PIN D7
  #endif

  // The number of milliseconds to flash the debug LED to indicate a successful publish
  #ifndef FATHYM_SINGLE_LED_DELAY
  #define FATHYM_SINGLE_LED_DELAY 20
  #endif

  // The number of milliseconds to flash the debug LED to indicate a successful publish
  #ifndef FATHYM_RGB_LED_DELAY
  #define FATHYM_RGB_LED_DELAY 150
  #endif

  // Device error states
  #define ERROR_NONE            0
  #define ERROR_JSON_BUFFER_MAX 1
  #define ERROR_CRITICAL        128

//==== End Debugging ============================================================================

//==== SD Card Storage ==========================================================================
/* This section is optional. Uncomment the lines below to enable the SD card storage features.
 * Data can be logged to SD card for archival purposes or as a temporary queue to ensure logged
 * data can postpone while network connections are lost and still publish later as well as be
 * power tolerant/non-volatile.
 */

 // Used for local data storage
 #ifdef FATHYM_USE_SD_STORAGE

    #ifdef LOCAL_BUILD
    // Photon compatible SD card library for storage capabilities
    #include "sd-card-library-photon-compat.h"
    #else
    #include "sd-card-library-photon-compat/sd-card-library-photon-compat.h"
    #endif // end include

    // Define SPI pins used to talk to SD card
    #define FATHYM_SD_CD    A1  // card detect
    #define FATHYM_SD_CS    A2  // chip select
    #define FATHYM_SD_MOSI  A5  // data in
    #define FATHYM_SD_MISO  A4  // data out
    #define FATHYM_SD_CLOCK A3  // data clock

 #endif // end FATHYM_USE_SD_STORAGE

 //==== End SD Card Storage =====================================================================


//==== Battery Shield ===========================================================================
/* This section is optional if you're creating a battery powered design that uses the SparkFun
 * Photon Battery Shield (https://www.sparkfun.com/products/13626). If you want to enable the
 * battery features then in your FathymBuild.h file somewhere put: #define FATHYM_USE_BATTERY_POWER
 */

// Used for battery power
#ifdef FATHYM_USE_BATTERY_POWER

  #ifdef LOCAL_BUILD
  // Used for JSON data communications
  #include "SparkFunMAX17043.h"
  #else
  #include "SparkFunMAX17043/SparkFunMAX17043.h"
  #endif // end include

  // Whether or not to report on battery voltage and charge level
  #ifndef FATHYM_MONITOR_BATTERY
  #define FATHYM_MONITOR_BATTERY true
  #endif

  // If monitoring battery power, whether or not to include the voltage level
  #ifndef FATHYM_ADD_BATTERY_VOLTAGE
  #define FATHYM_ADD_BATTERY_VOLTAGE true
  #endif

  // The name of the battery voltage memory property to use
  #ifndef FATHYM_BATTERY_VOLTAGE_PROPERTY
  #define FATHYM_BATTERY_VOLTAGE_PROPERTY "batV"
  #endif

  // If monitoring battery power, whether or not to include the charge level
  #ifndef FATHYM_ADD_BATTERY_CHARGE
  #define FATHYM_ADD_BATTERY_CHARGE true
  #endif

  // The name of the battery voltage memory property to use
  #ifndef FATHYM_BATTERY_CHARGE_PROPERTY
  #define FATHYM_BATTERY_CHARGE_PROPERTY "batC"
  #endif

#endif // end FATHYM_USE_BATTERY_POWER

//==== End Battery Shield =======================================================================

// Fathym API class
class Fathym;
//typedef void (Fathym::*MQTT_HANDLER)(const char * payload);

// Fathym remote/registered function handler
typedef String (*FathymFunction)(String args);

// Used for registering functions
typedef struct FunctionRegistration
{
  String name; // the name the function is registered under
  FathymFunction func; // pointer to the function that is registered
} FunctionRegistration;

// Main Fathym class that provides singleton-like access to the API
class Fathym {
public:
  // Constructors
  Fathym();

  // Event Handlers
  void nameHandler(const char * topic, const char * data); // used to retrieve device name
  void sdCardCardHandler(void); // handles changes to SD card availability

  // Device
  void setup(void);

  // Refresh/Visuals
  float _brightness = 1.0;

  // Connection
  void beginUpdate(void);
  void endUpdate(void);
  bool connect(char * server, char * username, char * password);
  bool connect(char * server, uint16_t port, char * username, char * password);
  bool isConnected(void);
  void setKeepAlive(uint16_t seconds);

  // Message
  void setPublishRate(uint16_t seconds);
  bool publishRaw(const char * topic, const char * payload, uint16_t delayMs);
  bool publish(void);
  bool publish(const char * topic);
  void remove(const char * name);
  void set(const char * name, bool value);
  void set(const char * name, const char * value);
  void set(const char * name, float value);
  void set(const char * name, float value, uint8_t decimals);
  void set(const char * name, double value);
  void set(const char * name, double value, uint8_t decimals);
  void set(const char * name, int value);
  void set(const char * name, long value);
  void set(const char * name, float value, const char * units);
  void set(const char * name, float value, const char * units, uint8_t decimals);
  void set(const char * name, double value, const char * units);
  void set(const char * name, double value, const char * units, uint8_t decimals);
  void set(const char * name, int value, const char * units);
  void set(const char * name, long value, const char * units);
  void printJson(void);
  void receive(char * topic, byte * payload, unsigned int length);

  // Control
  bool registerFunction(const char * name, FathymFunction function);

private:
  // Device
  String _id; // stores the device's ID
  String _idProp = FATHYM_ID_PROPERTY; // the property name to use for the device ID
  String _name; // stores the device's name
  String _timeStamp; // stores the current timestamp string for the last publish
  uint16_t _publishRate; // rate (in seconds) at which auto-publishing occurs if it is enabled
  unsigned long _lastTimeSync; // used to resync to cloud network time to avoid local time drift
  unsigned long _lastBeginUpdate; // used to adjust delay compensation to attempt to regulate a more stable update/publish rate
  String _sendTopic; // the device-specific send topic
  String _receiveTopic; // the device-specific receive topic
  String _publishTopic; // the device specific publish topic
  String _msgId; // the ID of the current message request/response
  uint8_t _error; // used to indicate the error state of the device (if any)
  String _errorJson; // string used to send a device error message

  // HTTP Endpoint
  String _httpHost;
  String _httpUrl;
  String _httpRequest;
  String _httpData;
  uint16_t _httpPort;
  int httpPost(String postData);

  // MQTT Connection
  char * _mqttServer;
  uint16_t _mqttPort;
  char * _mqttUsername;
  char * _mqttPassword;
  MQTT * _mqtt;
  uint16_t _mqttKeepAlive;
  String _mqttResponse;
  bool _subscribed;
  bool subscribe(void);
  bool reconnect(bool flash);

  // Control
  bool _configChanged = false;
  void writePin(uint8_t mode, const char * pin, JsonVariant value);
  String callRegFunction(String name, String args);
  uint8_t _funcIndex = 0;
  FunctionRegistration _funcRegs[32];

  // Storage
  FlashDevice * _flash;

  // optional SD card storage
  #ifdef FATHYM_USE_SD_STORAGE
  bool _sdCardAvailable = false;
  bool _waitingToPublish = false;
  const char * _publishFileName = "pub.txt";
  File _pubFile;
  void enableSdCard(void);
  #endif

  // JSON
  DynamicJsonBuffer _jsonBuffer;
  JsonObject * _json;
  DynamicJsonBuffer _configBuffer;
  JsonObject * _config;
  String _configJson;

  // Utility
  String createUUID();
  bool applyConfig(JsonObject & values, bool save);
  void flash(uint8_t numFlashes, uint8_t delayMs);
  void flashRGB(uint8_t numFlashes, uint8_t delayMs, uint8_t r, uint8_t g, uint8_t b);
  void showReceiveError(void);
};

// Singleton instance to use
//extern Fathym fathym; // this is causing an error when building for some reason

#endif
